package cl.duoc.andesstay.bff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAndesstayBffApplicationTests {

	@Test
	void contextLoads() {
	}

}
